package com.corsuevisionplus.tamazuj.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.corsuevisionplus.tamazuj.R
import com.corsuevisionplus.tamazuj.databinding.RvTimesCellBinding
import com.corsuevisionplus.tamazuj.models.DataTime




class RestAdapter(private val context: Context, arrayList: List<DataTime>) :
        RecyclerView.Adapter<RestAdapter.ExpensesViewHolder>() {
    private val arrayList: List<DataTime>
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpensesViewHolder {
        val v: View = LayoutInflater.from(context).inflate(R.layout.rv_times_cell, parent, false)
        return ExpensesViewHolder(v)
    }

    override fun onBindViewHolder(holder: ExpensesViewHolder, position: Int) {
        holder.openType.text = arrayList[position].openType.toString()
        holder.timeStart.text = arrayList[position].timeStart
        holder.timeEnd.text = arrayList[position].timeEnd

    }

    override fun getItemCount(): Int {
        return arrayList.size
    }

    inner class ExpensesViewHolder(itemView: View) :
            RecyclerView.ViewHolder(itemView) {
        var openType: TextView
        var timeStart: TextView
        var timeEnd: TextView


        init {
            openType = itemView.findViewById(R.id.typeOpen)
            timeStart = itemView.findViewById(R.id.timeStart)
            timeEnd = itemView.findViewById(R.id.timeEnd)

        }
    }

    init {
        this.arrayList = arrayList
    }
}