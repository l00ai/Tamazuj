package com.corsuevisionplus.tamazuj.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName
import javax.annotation.Generated


class Datum {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("profile_photo_url")
    @Expose
    var profilePhotoUrl: String? = null

    @SerializedName("rating")
    @Expose
    var rating: Int? = null

    @SerializedName("rating_percentage")
    @Expose
    var ratingPercentage: Int? = null

    @SerializedName("fields")
    @Expose
    var fields: List<Field>? = null
}