package com.corsuevisionplus.tamazuj.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Field {
    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("price")
    @Expose
    var price: Double? = null
    @SerializedName("online_minute_price")
    @Expose
    var onlineMinutePrice: Double? = null

    @SerializedName("pivot")
    @Expose
    var pivot: Pivot? = null
}
