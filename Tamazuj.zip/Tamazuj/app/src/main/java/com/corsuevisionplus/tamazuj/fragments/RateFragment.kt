package com.corsuevisionplus.tamazuj.fragments

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.corsuevisionplus.tamazuj.R
import com.corsuevisionplus.tamazuj.activities.MainDrawerActivity
import com.corsuevisionplus.tamazuj.databinding.FragmentRateBinding
import javax.annotation.Generated



class RateFragment : Fragment() {
    private lateinit var binding: FragmentRateBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = FragmentRateBinding.inflate(inflater,container,false)
        binding = view



        return binding.root
    }

}