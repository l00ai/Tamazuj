package com.corsuevisionplus.tamazuj.api.response

import com.corsuevisionplus.tamazuj.models.FieldOnline
import com.corsuevisionplus.tamazuj.models.Datum
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class FailedResponse {
    @SerializedName("states")
    @Expose
    var states: Boolean? = null

    @SerializedName("data")
    @Expose
    var data: List<Datum>? = null

    @SerializedName("dataOnline")
    @Expose
    var fieldOnline: List<FieldOnline>? = null
}

