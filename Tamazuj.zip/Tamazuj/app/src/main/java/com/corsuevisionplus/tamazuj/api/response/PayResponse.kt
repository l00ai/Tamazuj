package com.corsuevisionplus.tamazuj.api.response

import com.corsuevisionplus.tamazuj.models.OnlineData
import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class PayResponse {
    @SerializedName("states")
    @Expose
    var states: Boolean? = null

    @SerializedName("bay_link")
    @Expose
    var bayLink: String? = null
    @SerializedName("online_data")
    @Expose
    var onlineData: OnlineData? = null
}
