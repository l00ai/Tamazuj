package com.corsuevisionplus.tamazuj.fragments

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.URLUtil
import android.widget.*
import com.corsuevisionplus.tamazuj.api.ApiClient
import com.corsuevisionplus.tamazuj.api.ApiInterface
import com.corsuevisionplus.tamazuj.api.response.FailedResponse
import com.corsuevisionplus.tamazuj.api.response.PayResponse
import com.corsuevisionplus.tamazuj.databinding.FragmentOnlineBinding
import com.corsuevisionplus.tamazuj.models.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*


class OnlineFragment : Fragment() {

    private lateinit var binding: FragmentOnlineBinding
    private lateinit var sp: Spinner
    private lateinit var sp2: Spinner
    private lateinit var field: Pivot
    private lateinit var doctor: FieldOnline
    override fun onCreateView
                (inflater: LayoutInflater, container: ViewGroup?,
                 savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view = FragmentOnlineBinding.inflate(inflater,container,false)
        binding = view
        sp = binding.chooseAdvice
        fieldsOnlineApi(this.activity?.application)
        sp2 = binding.chooseTheDoctor
        doctorsOnlineApi(this.activity?.application)

        binding.request.setOnClickListener {
            roomNewOnline()
        }

        return binding.root
    }
    private fun fieldsOnlineApi(activity: Context?){

        val service: ApiInterface = ApiClient().retrofitInstance!!.create(ApiInterface::class.java)
        val call = service.getFieldsOnline()
        call.enqueue(object : Callback<FailedResponse> {
            override fun onResponse(
                call: Call<FailedResponse>,
                response: Response<FailedResponse>
            ) {

                val res = response.body()!!.data!!
                val f = mutableListOf<List<Field>>()
                for (n in res) {
                    f.add(n.fields!!)
                }

                val arrayData = mutableListOf<String>()

                for (n in f) {
                    for (x in n) {
                        arrayData.add(x.name!!)

                    }
                }

                sp.adapter = ArrayAdapter(activity!!, android.R.layout.simple_list_item_1, arrayData)

            }

            override fun onFailure(call: Call<FailedResponse>, t: Throwable) {
                Log.e("LOI", t.message.toString())
            }

        })
    }
    private fun doctorsOnlineApi(activity: Context?){
        val service: ApiInterface = ApiClient().retrofitInstance!!.create(ApiInterface::class.java)
        val call = service.getDoctorsOnline()
        call.enqueue(object : Callback<FailedResponse> {
            override fun onResponse(
                call: Call<FailedResponse>,
                response: Response<FailedResponse>
            ) {
                val res = response.body()!!.data!!
                val arrayData = mutableListOf<String>()
                for (n in res) {
                    arrayData.add(n.name!!)
                }

                sp2.adapter = ArrayAdapter(
                    activity!!,
                    android.R.layout.simple_list_item_1,
                    arrayData
                )
            }

            override fun onFailure(call: Call<FailedResponse>, t: Throwable) {
                Log.e("LOI", t.message.toString())
            }
        })

    }
    private fun roomNewOnline(){
        binding.operationSpinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p0: AdapterView<*>?) {

            }
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                binding.operationSpinner.selectedItem.toString()
            }

        }
        val doctorID = doctor.id
        val fieldID = field.fieldId
        val note = binding.noteOnline.text.toString()
        val payType = "PayPal"
        val mun = binding.operationSpinner.selectedItem.toString()

        val service: ApiInterface = ApiClient().retrofitInstance!!.create(ApiInterface::class.java)
        Log.d(
                "Room_Online",
                "${doctorID}${fieldID}${note}${payType}${mun}"
        )
        val call = service.roomNewOnline(doctorID!!,fieldID!!,note,"",mun)
        call.enqueue(object : Callback<PayResponse>{
            override fun onResponse(
                    call: Call<PayResponse>,
                    response: Response<PayResponse>
            ) {
                if (response.code() == 200) {
                    val body = response.body()
                    if (body!!.states!!) {

                        isValidUrl(body.bayLink)

                    }
                } else if (response.code() == 400) {
                    Toast.makeText(activity, "Error", Toast.LENGTH_LONG)
                            .show()

                }

            }

            override fun onFailure(call: Call<PayResponse>, t: Throwable) {
                Toast.makeText(activity, t.localizedMessage, Toast.LENGTH_LONG)
                        .show()
            }

        })

    }
    private fun isValidUrl(url: String?): Boolean {
        if (url == null) {
            return false
        }
        if (URLUtil.isValidUrl(url)) {
            val uri = Uri.parse(url)
            if (url == uri.host) {
                return true
            }
        }
        return false
    }
}