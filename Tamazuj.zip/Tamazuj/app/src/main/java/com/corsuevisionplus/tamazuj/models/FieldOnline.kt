package com.corsuevisionplus.tamazuj.models

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName


class FieldOnline {
    @SerializedName("id")
    @Expose
    var id: Int? = null

    @SerializedName("name")
    @Expose
    var name: String? = null

    @SerializedName("email")
    @Expose
    var email: String? = null

    @SerializedName("email_verified_at")
    @Expose
    var emailVerifiedAt: Any? = null

    @SerializedName("current_team_id")
    @Expose
    var currentTeamId: Any? = null

    @SerializedName("profile_photo_path")
    @Expose
    var profilePhotoPath: Any? = null

    @SerializedName("available")
    @Expose
    var available: Int? = null

    @SerializedName("status")
    @Expose
    var status: String? = null

    @SerializedName("profile_photo_url")
    @Expose
    var profilePhotoUrl: String? = null

    @SerializedName("rating")
    @Expose
    var rating: Int? = null

    @SerializedName("rating_percentage")
    @Expose
    var ratingPercentage: Int? = null

    @SerializedName("fields")
    @Expose
    var fields: List<Field>? = null
}