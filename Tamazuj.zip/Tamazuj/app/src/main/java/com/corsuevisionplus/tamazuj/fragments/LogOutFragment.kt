package com.corsuevisionplus.tamazuj.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.corsuevisionplus.tamazuj.databinding.FragmentLogOutBinding


class LogOutFragment : Fragment() {
    private lateinit var binding: FragmentLogOutBinding
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view = FragmentLogOutBinding.inflate(inflater, container, false)
        binding = view



        return binding.root
    }

    }
 /*   private fun logOutApi(){
        val service: ApiInterface = ApiClient().retrofitInstance!!.create(ApiInterface::class.java)
        val call = service.logOutUser()
        call.enqueue(object : Callback<LogOutResponse> {
            override fun onResponse(
                call: Call<LogOutResponse>,
                response: Response<LogOutResponse>
            ) {
                if (response.code() == 200) {
                    val body = response.body()
                    if (body!!.status!!) {

                        Toast.makeText(activity, body.message, Toast.LENGTH_LONG)
                            .show()
                        userLogOut()
                        val intent = Intent(activity, LogInActivity::class.java)
                        startActivity(intent)

                    } else {
                        Toast.makeText(activity, body.message, Toast.LENGTH_LONG)
                            .show()
                    }
                } else if (response.code() == 400) {
                    Toast.makeText(activity, "Error", Toast.LENGTH_LONG)
                        .show()
                }
            }

            override fun onFailure(call: Call<LogOutResponse>?, t: Throwable?) {

                Toast.makeText(activity, t!!.localizedMessage, Toast.LENGTH_LONG)
                    .show()
            }
        })
    }


    private fun userLogOut(){
        SharedPrefManager.getInstance(requireContext().applicationContext)!!.logout()
    }*/
