package com.corsuevisionplus.tamazuj.fragments


import android.R
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.URLUtil
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.corsuevisionplus.tamazuj.activities.DateAvailableActivity
import com.corsuevisionplus.tamazuj.api.ApiClient
import com.corsuevisionplus.tamazuj.api.ApiInterface
import com.corsuevisionplus.tamazuj.api.response.FailedResponse
import com.corsuevisionplus.tamazuj.api.response.PayResponse
import com.corsuevisionplus.tamazuj.databinding.FragmentInClinicBinding
import com.corsuevisionplus.tamazuj.models.DataTime
import com.corsuevisionplus.tamazuj.models.Datum
import com.corsuevisionplus.tamazuj.models.Field
import com.corsuevisionplus.tamazuj.models.Pivot
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class InClinicFragment : Fragment() {

    private lateinit var binding: FragmentInClinicBinding
    private lateinit var sp: Spinner
    private lateinit var sp2: Spinner
    private lateinit var dateTimeStart: DataTime
    private lateinit var dataTimeEnd: DataTime
    private lateinit var field: Pivot
    private lateinit var doctor: Datum


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = FragmentInClinicBinding.inflate(inflater, container, false)
        binding = view

        sp = binding.chooseAdviceIN
        fieldsApi(this.activity?.application)
        sp2 = binding.chooseTheDoctorIN
        doctorsApi(this.activity?.application)
        binding.viewAvailable.setOnClickListener {
            startActivity(Intent(activity, DateAvailableActivity::class.java))
        }



        return binding.root
    }


    private fun fieldsApi(activity: Context?){

        val service: ApiInterface = ApiClient().retrofitInstance!!.create(ApiInterface::class.java)
        val call = service.getFields()
        call.enqueue(object : Callback<FailedResponse> {
            override fun onResponse(
                call: Call<FailedResponse>,
                response: Response<FailedResponse>
            ) {

                val res = response.body()!!.data!!
                val f = mutableListOf<List<Field>>()
                for (n in res) {
                    f.add(n.fields!!)
                }

                val arrayData = mutableListOf<String>()

                for (n in f) {
                    for (x in n) {
                        arrayData.add(x.name!!)

                    }
                }

                sp.adapter = ArrayAdapter(activity!!, R.layout.simple_list_item_1, arrayData)

            }

            override fun onFailure(call: Call<FailedResponse>, t: Throwable) {
                Log.e("LOI", t.message.toString())
            }

        })
    }
            private fun doctorsApi(activity: Context?){
                val service: ApiInterface = ApiClient().retrofitInstance!!.create(ApiInterface::class.java)
                val call = service.getDoctors()
                call.enqueue(object : Callback<FailedResponse> {
                    override fun onResponse(
                        call: Call<FailedResponse>,
                        response: Response<FailedResponse>
                    ) {
                        val res = response.body()!!.data!!
                        val arrayData = mutableListOf<String>()
                        for (n in res) {
                            arrayData.add(n.name!!)
                        }

                        sp2.adapter = ArrayAdapter(
                            activity!!,
                            R.layout.simple_list_item_1,
                            arrayData
                        )
                    }

                    override fun onFailure(call: Call<FailedResponse>, t: Throwable) {
                        Log.e("LOI", t.message.toString())
                    }
                })

}
                private fun roomNew(){
            val doctorID = doctor.id
            val fieldID = field.fieldId
            val note = binding.notes.text.toString()
            val dateStart = dateTimeStart.dateTo
            val dateEnd =   dataTimeEnd.dateFrom


            val service: ApiInterface = ApiClient().retrofitInstance!!.create(ApiInterface::class.java)
                    Log.d(
                        "Room_Data",
                        "${doctorID}${fieldID}${""}${note}${dateStart}${dateEnd}"
                    )
            val call = service.roomNew(doctorID!!, fieldID!!, "", note, dateStart!!, dateEnd!!)
                    call.enqueue(object : Callback<PayResponse> {
                        override fun onResponse(
                            call: Call<PayResponse>,
                            response: Response<PayResponse>
                        ) {
                            if (response.code() == 200) {
                                val body = response.body()
                                if (body!!.states!!) {

                                    isValidUrl(body.bayLink)

                                }
                            } else if (response.code() == 400) {
                                Toast.makeText(activity, "Error", Toast.LENGTH_LONG)
                                    .show()

                            }

                        }

                        override fun onFailure(call: Call<PayResponse>, t: Throwable) {
                            Toast.makeText(activity, t.localizedMessage, Toast.LENGTH_LONG)
                                .show()
                        }

                    })

}
    private fun isValidUrl(url: String?): Boolean {
        if (url == null) {
            return false
        }
        if (URLUtil.isValidUrl(url)) {
            val uri = Uri.parse(url)
            if (url == uri.host) {
                return true
            }
        }
        return false
    }
    }



