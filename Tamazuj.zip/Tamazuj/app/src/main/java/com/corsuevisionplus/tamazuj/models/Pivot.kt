package com.corsuevisionplus.tamazuj.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import javax.annotation.Generated


class Pivot {
    @SerializedName("field_id")
    @Expose
    var fieldId: Int? = null
}