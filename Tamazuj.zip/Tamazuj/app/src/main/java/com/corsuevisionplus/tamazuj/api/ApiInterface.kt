package com.corsuevisionplus.tamazuj.api

import com.corsuevisionplus.tamazuj.api.response.*
import retrofit2.Call
import retrofit2.http.*


interface ApiInterface {
    @FormUrlEncoded
    @POST("api-v1/auth/register")
    fun register(@Field("name") name: String,
                 @Field("email") email: String,
                 @Field("phone") phone: String,
                 @Field("lang") language: String,
                 @Field("gender") gender: String,
                 @Field("date_of_berth") dateOfBerth: String,
                 @Field("fcm_token") fcm_token: String,
                 @Field("password") password: String,
                 @Field("password_confirmation") cpassword: String
    ): Call<CommonResponse>


    @FormUrlEncoded
    @POST("api-v1/auth/login")
    fun logIn(@Field("email") email: String,
              @Field("password") password: String,
              @Field("fcm_token") fcm_token: String
    ): Call<CommonResponse>

    @FormUrlEncoded
    @POST("api-v1/customer-reset-password/send-reset-password")
    fun rest(@Field("email") email: String
    ): Call<RestResponse>

    @GET("api-v1/room-reservations/get-doctors-failed")
    fun getFields(): Call<FailedResponse>

    @GET("api-v1/room-reservations/get-doctors-failed")
    fun getDoctors(): Call<FailedResponse>

    @FormUrlEncoded
    @POST("api-v1/room-reservations/get-available-times")
    fun availableTime(@Field("date") date: String
    ): Call<TimeResponse>
    @FormUrlEncoded
    @POST("api-v1/room-reservations/bay-new-room-consulting")
    fun roomNew(@Field("doctor_id") doctor_id: Int,
                 @Field("field_id") field_id: Int,
                 @Field("payment_type") payment_type: String,
                 @Field("note") note: String,
                 @Field("room_consultant_at_from") room_consultant_at_from: String,
                 @Field("room_consultant_at_to") room_consultant_at_to: String
    ): Call<PayResponse>






    @GET("api-v1/online-reservations/get-online-doctors")
    fun getFieldsOnline(): Call<FailedResponse>
    @GET("api-v1/online-reservations/get-online-doctors")
    fun getDoctorsOnline(): Call<FailedResponse>

    @POST("api-v1/online-reservations/bay-new-online-consulting")
    fun roomNewOnline(@Field("doctor_id") doctor_id: Int,
                @Field("field_id") field_id: Int,
                      @Field("note") note: String,
                @Field("payment_type") payment_type: String,
                @Field("minutes") minutes: String
    ): Call<PayResponse>

}

