package com.corsuevisionplus.tamazuj.activities

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.corsuevisionplus.tamazuj.api.ApiClient
import com.corsuevisionplus.tamazuj.api.ApiInterface
import com.corsuevisionplus.tamazuj.api.response.CommonResponse
import com.corsuevisionplus.tamazuj.databinding.ActivityLogInBinding
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import javax.annotation.Generated


class LogInActivity : AppCompatActivity() {
    private lateinit var logInBinding: ActivityLogInBinding
    private lateinit var sharedPreferences: SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        logInBinding = ActivityLogInBinding.inflate(layoutInflater)
        val view = logInBinding.root
        setContentView(view)
        sharedPreferences = getSharedPreferences("SETTING_PREF", MODE_PRIVATE)
        readData()
        logInBinding.LogIn.setOnClickListener {
            loginApi()
        }
        logInBinding.signUp.setOnClickListener {
            val intent = Intent(this, SignUpActivity::class.java)
            startActivity(intent)
        }
        logInBinding.forgotPassword.setOnClickListener {
            val intent = Intent(this, RestActivity::class.java)
            startActivity(intent)
        }
    }


    private fun readData(){
        logInBinding.emailLogin.setText(sharedPreferences.getString("EMAIL", null))
        logInBinding.passwordLogin.setText(sharedPreferences.getString("PASSWORD", null))
    }
    private fun loginApi(){
        val email =logInBinding.emailLogin.text.toString()
        val password = logInBinding.passwordLogin.text.toString()
        val fcm = "fcm_token"
        val service: ApiInterface = ApiClient().retrofitInstance!!.create(ApiInterface::class.java)
        val call = service.logIn(email, password, fcm)
        call.enqueue(object : Callback<CommonResponse> {
            override fun onResponse(
                    call: Call<CommonResponse>,
                    response: Response<CommonResponse>
            ) {
                if (response.code() == 200) {
                    val body = response.body()
                    if (body!!.status!!) {
                        val gson = Gson()
                        val userObject = gson.toJson(body!!.userInfo)
                        Toast.makeText(this@LogInActivity, userObject, Toast.LENGTH_LONG)
                                .show()
                        finish()
                        val intent = Intent(this@LogInActivity, ConsultationsActivity::class.java)
                        startActivity(intent)
                        val edit = sharedPreferences.edit()
                        edit.putString("EMAIL", logInBinding.emailLogin.text.toString())
                        edit.putString("PASSWORD", logInBinding.passwordLogin.text.toString())
                        edit.putString("USER", userObject)
                        edit.apply()

                    } else {
                        Toast.makeText(this@LogInActivity, body.userInfo.toString(), Toast.LENGTH_LONG)
                                .show()
                    }
                } else if (response.code() == 400) {
                    Toast.makeText(this@LogInActivity, "Error", Toast.LENGTH_LONG)
                            .show()
                }
            }

            override fun onFailure(call: Call<CommonResponse>?, t: Throwable?) {

                Toast.makeText(this@LogInActivity, t!!.localizedMessage, Toast.LENGTH_LONG)
                        .show()
            }
        })
    }


}
